<?php foreach ($posts as $post): ?>
  <div class="col-md-12 content">
      <h6 class="text-center text-danger" style="font-size:12px;">Pelantikan Pengurus DPW Pengurus DPW Sulawesi-Selatan</h6>
      <b>Detail Acara :</b>
      <table>
        <tr>
          <td>Tanggal</td>
          <td>: 10 november 2019</td>
        </tr>

        <tr>
          <td>Pukul</td>
          <td>: 13:00 WITA s/d selesai</td>
        </tr>

        <tr>
          <td>Alamat</td>
          <td>: Jl. Mannuruki raya lr garden pondok 16</td>
        </tr>
      </table>
  </div>
<?php endforeach; ?>
