<div class="content-wrapper" style="margin-bottom:35px;">
  <div class="mt-3 text-center main-ppob">
    <h5 class="text-center"> Layanan PPOB</h5>

    <h6 class="text-center text-primary" style="font-size:13px;">SALDO Rp.0</h6>

    <div class="ppob-content">

      <div class="ppob-menu">
        <a href="#">
          <span><img src="<?=base_url()?>_template/icon/bpjs.png" alt=""></span>
          <p class="text-center">BPJS</p>
        </a>
      </div>

      <div class="ppob-menu">
        <a href="#">
          <span><img src="<?=base_url()?>_template/icon/token-pln.png" alt=""></span>
          <p class="text-center">TOKEN PLN</p>
        </a>
      </div>

      <div class="ppob-menu">
        <a href="#">
          <span><img src="<?=base_url()?>_template/icon/pdam.png" alt=""></span>
          <p class="text-center">PDAM</p>
        </a>
      </div>

      <div class="ppob-menu">
        <a href="#">
          <span><img src="<?=base_url()?>_template/icon/pulsa.png" alt=""></span>
          <p class="text-center">PULSA</p>
        </a>
      </div>

      <div class="ppob-menu">
        <a href="#">
          <span><img src="<?=base_url()?>_template/icon/pulsa-data.png" alt=""></span>
          <p class="text-center">PULSA DATA</p>
        </a>
      </div>


      <div class="ppob-menu">
        <a href="#">
          <span><img src="<?=base_url()?>_template/icon/voucher-game.png" alt=""></span>
          <p class="text-center">VOUCHER GAME</p>
        </a>
      </div>

    </div>

  </div>
</div>
