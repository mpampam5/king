<div class="content-wrapper" style="margin-bottom:35px;">
  <div class="mt-3 support">
    <h5 class="mt-5 text-center">Support</h5>

    <div class="p-3">
      <p>Percakapan lansung melalui TIM kami melalui chat Whatsapp.</p>
      <ul>
        <li><i class="ti-check"></i> Riwayat percakapan tersimpan</li>
        <li><i class="ti-check"></i> Menunggu antrian untuk di layani TIM</li>
        <li><i class="ti-check"></i> 5 hari kerja. Di saat jam kerja</li>
      </ul>

      <a href="#" class="btn btn-md btn-block btn-success"> Chat Whatsapp</a>

      <div class="text-center">
        <p class="mt-5">Atau hubungi kami melalui email</p>
        <b><a href="mailto:mpampam5@gmail.com">info@jpkp.com</a></b>
      </div>


      <div class="text-center mt-4">
        <a href="#" class="btn btn-md btn-block btn-primary"> Facebook</a>
      </div>


    </div>
  </div>
</div>
