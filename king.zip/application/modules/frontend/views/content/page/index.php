<div class="content-wrapper bg-white" style="margin-bottom:35px;">
  <div class="pb-5 bg-white p-3 page">
    <h5 class="mb-4 mt-3 text-center"><?=strtoupper($row->title)?></h5>
    <div class="mt-3 content">
      <?=$row->keterangan?>
    </div>
  </div>



</div>
