<div class="row">
  <div class="col-lg-12">
    <p>Tgl Post : <?=date("d/m/Y H:i",strtotime($created))?></p>
    <p><?=$keterangan?></p>
    <hr>
    <button type='button' class='btn btn-default btn-sm' data-dismiss='modal'>Cancel</button>
  </div>
</div>
